# FWC Bangladesh Premier League Auction: Android app

A tiny native Android wrapper (WebView) around the auction page.
The page lives in `app/src/main/assets/index.html`.

Needs Android 10 or newer. Exports (Save Record, Export CSV, ledger) are saved to `Downloads/FWC Auction`.

## Option A: Android Studio (on a PC)
1. Install Android Studio and choose File > Open, then pick this folder.
2. Wait for Gradle sync to finish.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. The file is at `app/build/outputs/apk/debug/app-debug.apk`. Copy it to your phone and tap it to install
   (allow "Install unknown apps" for your file manager or browser when asked).

## Option B: build in the cloud with GitHub (no Android Studio)
1. Create a new GitHub repository and upload everything in this folder
   (keep the `.github` folder; it holds the build workflow).
2. Open the repository's Actions tab. The "Build APK" workflow runs on every push
   (or press Run workflow).
3. When it finishes, open the run and download the `FWC-BPL-Auction-apk` artifact.
   It is a zip containing `app-debug.apk`.

## Editing the game later
Replace `app/src/main/assets/index.html` with the new HTML and build again.
Keep the small `<script>` block right after `<head>`; it makes the exports work inside the app.
